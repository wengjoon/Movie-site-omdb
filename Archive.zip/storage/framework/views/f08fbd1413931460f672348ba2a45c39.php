


<title>
    <?php echo $__env->yieldContent('seo_title', config('seo.default_title')); ?>
</title>
<meta name="description" content="<?php echo $__env->yieldContent('seo_description', config('seo.default_description')); ?>">
<meta name="keywords" content="<?php echo $__env->yieldContent('seo_keywords', config('seo.default_keywords')); ?>">


<meta property="og:title" content="<?php echo $__env->yieldContent('seo_title', config('seo.default_title')); ?>">
<meta property="og:description" content="<?php echo $__env->yieldContent('seo_description', config('seo.default_description')); ?>">
<meta property="og:type" content="<?php echo $__env->yieldContent('og_type', 'website'); ?>">
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:image" content="<?php echo $__env->yieldContent('og_image', asset(config('seo.default_og_image'))); ?>">
<meta property="og:site_name" content="<?php echo e(config('seo.site_name')); ?>">


<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $__env->yieldContent('seo_title', config('seo.default_title')); ?>">
<meta name="twitter:description" content="<?php echo $__env->yieldContent('seo_description', config('seo.default_description')); ?>">
<meta name="twitter:image" content="<?php echo $__env->yieldContent('twitter_image', asset(config('seo.default_twitter_image'))); ?>">


<link rel="canonical" href="<?php echo $__env->yieldContent('canonical_url', url()->current()); ?>"><?php /**PATH /Users/mouadbrody/movie-site/resources/views/partials/seo-meta.blade.php ENDPATH**/ ?>