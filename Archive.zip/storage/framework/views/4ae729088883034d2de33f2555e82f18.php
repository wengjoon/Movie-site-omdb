<?php
    $seoTitle = "Search Results for \"{$query}\" - 123 Movies Pro";
    $seoDescription = "Search results for {$query} - Watch free HD movies and TV shows on 123 Movies Pro. Stream online with no signup required.";
    $seoKeywords = "123 movies pro, {$query}, search results, free streaming, watch online, HD movies";
?>

<?php $__env->startSection('seo_title', $seoTitle); ?>
<?php $__env->startSection('seo_description', $seoDescription); ?>
<?php $__env->startSection('seo_keywords', $seoKeywords); ?>
<?php $__env->startSection('canonical_url', route('movies.search', ['query' => $query])); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="search-header">
        <h1>Results for "<?php echo e($query); ?>"</h1>
        <form action="<?php echo e(route('movies.search')); ?>" method="get" class="mt-3">
            <div class="input-group">
                <input type="text" name="query" class="form-control search-input" value="<?php echo e($query); ?>" placeholder="Search for movies...">
                <button class="btn btn-primary search-btn" type="submit">Search</button>
            </div>
        </form>
    </div>

    <?php if(count($results) > 0): ?>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="movie-card h-100">
                        <a href="<?php echo e(route('movies.show', ['id' => $movie['id']])); ?>" class="text-decoration-none">
                            <?php if($movie['poster_path']): ?>
                                <img src="https://image.tmdb.org/t/p/w500<?php echo e($movie['poster_path']); ?>" class="card-img-top" alt="<?php echo e($movie['title']); ?> poster - Watch on 123 Movies Pro" loading="lazy">
                            <?php else: ?>
                                <div class="card-img-top bg-secondary d-flex align-items-center justify-content-center">
                                    <span class="text-light"><i class="bi bi-film" style="font-size: 3rem;"></i></span>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="movie-title" title="<?php echo e($movie['title']); ?>"><?php echo e($movie['title']); ?></h5>
                                <?php if(isset($movie['release_date']) && !empty($movie['release_date'])): ?>
    <p class="movie-year"><?php echo e(substr($movie['release_date'], 0, 4)); ?></p>
<?php endif; ?>
                                <p class="movie-rating">
    <i class="bi bi-star-fill me-1"></i> 
    <?php echo e(isset($movie['vote_average']) ? number_format($movie['vote_average'], 1) : 'N/A'); ?>/10
</p>
                                <div class="movie-hover-info">
                                    <div class="hover-buttons">
                                        <a href="<?php echo e(route('movies.show', ['id' => $movie['id']])); ?>" class="btn btn-sm btn-danger">
                                            <i class="bi bi-info-circle me-1"></i> Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($total_pages > 1): ?>
            <div class="d-flex justify-content-center mt-5">
                <nav aria-label="Search results pages">
                    <ul class="pagination">
                        <?php if($current_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e(route('movies.search', ['query' => $query, 'page' => $current_page - 1])); ?>" rel="prev">
                                    <i class="bi bi-chevron-left"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php
                            $startPage = max(1, $current_page - 2);
                            $endPage = min($startPage + 4, $total_pages);
                            if ($endPage - $startPage < 4) {
                                $startPage = max(1, $endPage - 4);
                            }
                        ?>
                        
                        <?php for($i = $startPage; $i <= $endPage; $i++): ?>
                            <li class="page-item <?php echo e($i == $current_page ? 'active' : ''); ?>">
                                <a class="page-link" href="<?php echo e(route('movies.search', ['query' => $query, 'page' => $i])); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if($current_page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e(route('movies.search', ['query' => $query, 'page' => $current_page + 1])); ?>" rel="next">
                                    <i class="bi bi-chevron-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert" style="background-color: rgba(22, 22, 22, 0.7); color: white; border: 1px solid rgba(255, 255, 255, 0.1);">
            <div class="d-flex align-items-center">
                <i class="bi bi-exclamation-circle me-3" style="font-size: 2rem;"></i>
                <div>
                    <h4 class="alert-heading">No Results Found</h4>
                    <p class="mb-0">We couldn't find any movies matching "<?php echo e($query); ?>". Please try different keywords.</p>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .search-header h1 {
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 1.2rem;
    }
    
    .movie-card {
        position: relative;
        overflow: hidden;
    }
    
    .movie-year {
        color: var(--netflix-light-gray);
        font-size: 0.9rem;
        margin-top: -0.5rem;
        margin-bottom: 0.5rem;
    }
    
    .movie-hover-info {
        position: absolute;
        bottom: -50px;
        left: 0;
        right: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.9), transparent);
        padding: 15px;
        transition: all 0.3s ease;
        opacity: 0;
    }
    
    .movie-card:hover .movie-hover-info {
        bottom: 0;
        opacity: 1;
    }
    
    .hover-buttons {
        display: flex;
        justify-content: center;
    }
    
    .hover-buttons .btn-danger {
        background-color: var(--netflix-red);
        border: none;
    }
    
    .hover-buttons .btn-danger:hover {
        background-color: #f40612;
    }
    
    /* Pagination */
    .pagination {
        margin-top: 2rem;
    }
    
    .page-link {
        background-color: var(--netflix-light-dark);
        border-color: #333;
        color: var(--netflix-text);
        padding: 0.5rem 0.8rem;
    }
    
    .page-item.active .page-link {
        background-color: var(--netflix-red);
        border-color: var(--netflix-red);
    }
    
    .page-link:hover {
        background-color: rgba(229, 9, 20, 0.7);
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mouadbrody/movie-site/resources/views/movies/search.blade.php ENDPATH**/ ?>