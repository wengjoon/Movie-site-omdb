<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark text-white">
                <div class="card-header bg-danger">Rate Limit Exceeded</div>
                <div class="card-body text-center">
                    <h3 class="card-title mb-4">Searching Too Quickly</h3>
                    <p class="card-text"><?php echo e($message ?? 'You are making too many requests. Please slow down.'); ?></p>
                    <div class="mt-4">
                        <a href="<?php echo e(route('movies.index')); ?>" class="btn btn-primary me-2">Home</a>
                        <button onclick="window.history.back()" class="btn btn-secondary">Go Back</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mouadbrody/movie-site1/resources/views/errors/429.blade.php ENDPATH**/ ?>